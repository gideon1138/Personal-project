export class HttpStatus {
  static IDLE = 'idle';
  static PENDING = 'pending';
  static FULFILLED = 'fulfilled';
  static REJECTED = 'rejected';
}