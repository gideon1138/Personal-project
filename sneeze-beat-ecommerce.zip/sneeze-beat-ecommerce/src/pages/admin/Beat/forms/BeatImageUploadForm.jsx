import React from 'react'

const BeatImageUploadForm = () => {
  return (
    <div>BeatImageUploadForm</div>
  )
}

export default BeatImageUploadForm