import React from 'react'
import CustomLayout from '../../../layouts'

const Page404 = () => {
  return (
    <CustomLayout>
      adahfslkjdhjkk
    </CustomLayout>
  )
}

export default Page404