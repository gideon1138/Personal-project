
export const RouteViewUrl = (path, Element, shortcut) => ({
  path: path,
  Element: Element,
  state: {
    shortcut: shortcut
  }
})

