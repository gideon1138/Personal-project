class HttpStatus {
  static IDLE = 'idle';
  static PENDING = 'pending';
  static FULFILED = 'fulfiled';
  static REDJECTED = 'rejected';
}

export default HttpStatus;